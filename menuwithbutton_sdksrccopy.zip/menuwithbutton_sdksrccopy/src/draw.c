/*
 * draw.c
 *
 *  Created on: Feb 18, 2023
 *      Author: 14379
 */
#include "draw.h"
u32 canvas[640*480];

void display_line(u32* frame, int xpos_start, int ypos_start, int xpos_end, int ypos_end, int clr, int weight) {
	int stride = 640;
	for (int wx = 0; wx < weight; wx ++ ) {
		for (int wy = 0; wy < weight; wy++) {
			//check in bound
			if (xpos_start + wx >= 640 || xpos_end + wx >= 640
					|| ypos_start + wy >= 480 || ypos_end + wy >=480) {
				continue;
			}
			draw_line (xpos_start + wx, ypos_start + wy, xpos_end + wx, ypos_end + wy, clr);
		}
	}
	int ulx, uly;
	ulx = (xpos_start > xpos_end) ? xpos_end : xpos_start;
	uly = (ypos_start > ypos_end) ? ypos_end : ypos_start;
	int delta_x = abs(xpos_start - xpos_end) + 1 + weight;
	int delta_y = abs(ypos_start - ypos_end) + 1 + weight;

	if (ulx + delta_x >= 640) {
		delta_x = 640 - ulx;
	}
	if (uly + delta_y >= 480) {
		delta_y = 480 - uly;
	}
//	btn_data = *button;
	//if button1
	//if ((btn_data & 0x3) == 0x2) {
	for (int y = uly; y < uly+delta_y; y++) {
		memcpy(frame + y*stride + ulx, canvas + y*stride + ulx, delta_x*4);
	}


}



void draw_line (int start_x, int start_y, int end_x, int end_y, u32 colour) {
	int num_pixel = (abs(start_x - end_x)+1) * (abs(start_y - end_y)+1);

	char is_steep;
	if (abs(end_y - start_y) > abs(end_x - start_x)) {
		is_steep = 1;
	} else {
		is_steep = 0;
	}

	if (is_steep == 1) {
		swap(&start_x, &start_y);
		swap(&end_x, &end_y);
	}
	if (start_x > end_x) {
		swap(&start_x, &end_x);
		swap(&start_y, &end_y);
	}

	int delta_x = end_x - start_x;
	int delta_y = abs(end_y - start_y);
	int error = (delta_x / 2) * -1;
	int y_step;
	if (start_y < end_y) {
		y_step = 1;
	} else {
		y_step = -1;
	}

	for (int x = start_x, y = start_y; x <= end_x; x++) {
		if (is_steep == 1) {
			canvas[x*640+y] = colour;
		} else {
			canvas[y*640+x] = colour;
		}
		error += delta_y;
		if (error >= 0) {
			y += y_step;
			error = error - delta_x;
		}
	}
}

void swap (int* first, int* second) {
	int temp;
	temp = *first;
	*first = *second;
	*second = temp;
}

int abs(int num) {
	if (num >= 0) {
		return num;
	}
	return -1 * num;
}
