/*
 * draw.h
 *
 *  Created on: Feb 18, 2023
 *      Author: 14379
 */

#ifndef SRC_DRAW_H_
#define SRC_DRAW_H_

#include "xil_types.h"

extern u32 canvas[640*480];

void display_line(u32* frame, int xpos_start, int ypos_start, int xpos_end, int ypos_end, int clr, int weight);
void swap (int* first, int* second);
int abs(int num);
void draw_line (int start_x, int start_y, int end_x, int end_y, u32 colour);

#endif /* SRC_DRAW_H_ */
