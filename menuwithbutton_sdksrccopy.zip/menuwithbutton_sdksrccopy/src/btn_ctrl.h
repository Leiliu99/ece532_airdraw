/*
 * btn_ctrl.h
 *
 *  Created on: Feb 18, 2023
 *      Author: 14379
 */

#ifndef SRC_BTN_CTRL_H_
#define SRC_BTN_CTRL_H_

#include "xil_types.h"



#define DRAW 1
#define CLR_SELECT 2
#define ERASE 3
#define TEXT 4
#define PIXEL_BLUE 0x00FF00
#define PIXEL_RED 0xFF0000
#define PIXEL_GREEN 0x0000FF
#define PIXEL_YELLOW 0xFF00FF
#define PIXEL_WHITE 0xFFFFFF
#define PIXEL_BLACK 0x010101
#define PIXEL_GREY 0x948F8F


int menu_switch(int option);
int clr_switch(int curr_clr);
void menu_display(u32 *frame, int option, int curr_clr);
void draw_square(u32 *frame, int length, int width, int xloc, int yloc, int clr);
void draw_clr_select(u32 *frame, int length, int width, int xloc, int yloc, int clr);
void clr_display(u32 *frame, int curr_clr);


#endif /* SRC_BTN_CTRL_H_ */
