/*
 * btn_ctrl.c
 *
 *  Created on: Feb 18, 2023
 *      Author: 14379
 */
#include "btn_ctrl.h"


int menu_switch(int option) {
	if (option == DRAW) {
		option = CLR_SELECT;
	} else if (option == CLR_SELECT) {
		option = DRAW;
	}
	return option;
}

int clr_switch(int curr_clr) {
	if (curr_clr == PIXEL_BLACK) {
		curr_clr = PIXEL_RED;
	} else if (curr_clr == PIXEL_RED) {
		curr_clr = PIXEL_BLUE;
	} else if (curr_clr == PIXEL_BLUE) {
		curr_clr = PIXEL_BLACK;
	}
	return curr_clr;
}

void menu_display(u32 *frame, int option, int curr_clr) {
	if (option == DRAW) {
		draw_square(frame, 50, 30, 0, 0, PIXEL_GREEN);
		draw_square(frame, 24, 74, 8, 68, PIXEL_WHITE);

	} else if (option == CLR_SELECT) {
		draw_square(frame, 50, 30, 0, 0, PIXEL_YELLOW);

		//display the current colours we have:
		//location: (10,70), (35, 70), (60, 70)
		//size: 20*20
		draw_square(frame, 20, 20, 10, 70, PIXEL_BLACK);
		draw_square(frame, 20, 20, 35, 70, PIXEL_RED);
		draw_square(frame, 20, 20, 60, 70, PIXEL_BLUE);

		if (curr_clr == PIXEL_BLACK) {
			draw_clr_select(frame, 24, 24, 8, 68, PIXEL_GREY);
		} else if (curr_clr == PIXEL_RED) {
			draw_clr_select(frame, 24, 24, 33, 68, PIXEL_GREY);
		} else if (curr_clr == PIXEL_BLUE) {
			draw_clr_select(frame, 24, 24, 58, 68, PIXEL_GREY);
		}

	}
}

//length: y, width: x
void draw_square(u32 *frame, int length, int width, int xloc, int yloc, int clr) {
	for (int y = 0; y < length; y++) {
		for (int x = 0; x < width; x++) {
			frame[(yloc + y)*640 + xloc + x] = clr;
		}
	}
}

void draw_clr_select(u32 *frame, int length, int width, int xloc, int yloc, int clr) {
	for (int x = 0; x < width; x++) {
		frame[yloc*640 + xloc + x] = clr;
		frame[(yloc + length - 1)*640 + xloc + x] = clr;
	}

	for (int y = 0; y < length; y++) {
		frame[(yloc + y)*640 + xloc] = clr;
		frame[(yloc + y)*640 + xloc + width - 1] = clr;
	}
}

void clr_display(u32 *frame, int curr_clr) {
	if (curr_clr == PIXEL_BLACK) {
		//prev at blue, first erase
		draw_clr_select(frame, 24, 24, 58, 68, PIXEL_WHITE);
		// highlight curr
		draw_clr_select(frame, 24, 24, 8, 68, PIXEL_GREY);
	} else if (curr_clr == PIXEL_RED) {
		draw_clr_select(frame, 24, 24, 8, 68, PIXEL_WHITE);
		draw_clr_select(frame, 24, 24, 33, 68, PIXEL_GREY);
	} else if (curr_clr == PIXEL_BLUE) {
		draw_clr_select(frame, 24, 24, 33, 68, PIXEL_WHITE);
		draw_clr_select(frame, 24, 24, 58, 68, PIXEL_GREY);
	}
}




